<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\bookController;
use App\Http\Controllers\employeeController;
use App\Http\Controllers;
use App\Models\book;
use App\Http\Controllers\Dummy;
use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::get('/login', function () {
    return view('login');
});

Route::get('/empcreate', function () {
    return view('employeecreate');
});

Route::get('/emppage', function () {
    return view('emppage');
});

Route::get('/admin', function () {
    return view('admin');
});

Route::get('/admin/bookshow', function () {
    return view('bookshow');
});

Route::get('//admin/bookshow/{$id}/delete', function(){
    return App::call('bookController@delete' , ['id' => $id]);
});


Route::resource('/admin/books', bookController::class);
Route::resource('/admin/employees', employeeController::class);
