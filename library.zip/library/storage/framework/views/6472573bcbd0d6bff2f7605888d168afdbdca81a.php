
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">
    <?php echo e($book->name); ?>

  </div>
  <div class="card-body">
    <h5 class="card-title">SWritten by: <?php echo e($book->authorname); ?> </h5>
    <p class="card-text">Book-ID: <?php echo e($book->id); ?> </p>
    <p class="card-text">Department: <?php echo e($book->idepartment); ?> </p>
    <p class="card-text">Section: <?php echo e($book->section); ?> </p>
    <p class="card-text">Total Copies: <?php echo e($book->taotal); ?> </p>
    <p class="card-text">Take home copies: <?php echo e($book->takehome); ?> </p>
    <p class="card-text">To read copies: <?php echo e($book->reading); ?> </p>
    <a href="/admin/books/<?php echo e($book->id); ?>/edit" class="btn btn-primary">Edit Book</a>
    <a href="/admin/books/<?php echo e($book->id); ?>/delete" class="btn btn-primary">Edit Book</a>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/bookid.blade.php ENDPATH**/ ?>