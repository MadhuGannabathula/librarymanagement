
<?php $__env->startSection('content'); ?>
<div class="header">
    <h2>CEdit book</h2>
</div>
<form method="post" action="/admin/books/<?php echo e($book->id); ?>" class="bookform">
        <?php echo csrf_field(); ?>;
        <?php echo e(method_field('PATCH')); ?>

        <div class="input-group">
            <label>Name of the Book</label>
            <input type="text" name="name" value="<?php echo e($book->name); ?>" >
        </div>
        <div class="input-group">
            <label>Name of the author</label>
            <input type="text" name="authorname" value="<?php echo e($book->authorname); ?>">
        </div>
        <div class="input-group">
            <label>Department</label>
            <input type="text" name="department" value="<?php echo e($book->department); ?>">
        </div>
        <div class="input-group">
            <label>Section</label>
            <input type="text" name="section" value="<?php echo e($book->section); ?>">
        </div>
        <div class="input-group">
            <label>To read copies</label>
            <input type="number" name="reading" value="<?php echo e($book->reading); ?>">
        </div>
        <div class="input-group">
            <label>Take home copies</label>
            <input type="number" name="takehome" value="<?php echo e($book->takehome); ?>">
        </div>
        <div class="input-group">
            <label>Total additional copies</label>
            <input type="number" name="takehome">
        </div>
        <div class="input-group">
            <button class="btn" name="submit">Update</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/editbook.blade.php ENDPATH**/ ?>