
<?php $__env->startSection('content'); ?>

<form method="post" action="/admin/books/<?php echo e($book->id); ?>" class="bookform">
        <?php echo csrf_field(); ?>;
        <div class="input-group">
            <label>Name of the Book</label>
            <input type="text" name="name" value="<?php echo e($book->name); ?>" >
        </div>
        <div class="input-group">
            <label>Name of the author</label>
            <input type="text" name="authorname" value="<?php echo e($book->authorname); ?>">
        </div>
        <div class="input-group">
            <label>Department</label>
            <input type="text" name="department" value="<?php echo e($book->department); ?>">
        </div>
        <div class="input-group">
            <label>Section</label>
            <input type="text" name="section" value="<?php echo e($book->section); ?>">
        </div>
        <div class="input-group">
            <label>TO read copies</label>
            <input type="integer" name="reading" value="<?php echo e($book->reading); ?>">
        </div>
        <div class="input-group">
            <label>Take home copies</label>
            <input type="integer" name="takehome" value="<?php echo e($book->takehome); ?>">
        </div>
        <div class="input-group">
            <button class="btn" name="submit">Update</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/bookupdate.blade.php ENDPATH**/ ?>