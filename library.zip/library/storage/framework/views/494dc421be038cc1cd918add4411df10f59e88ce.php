
<?php $__env->startSection('content'); ?>
<?php $head="Edit employee"; ?>
<div class="header">
        <h2>Employee</h2>
    </div>
      
    <form method="POST" action="http://127.0.0.1:8000/admin/employees/<?php echo e($employee->id); ?>" class="bookform">
    <?php echo csrf_field(); ?>;
    <?php echo e(method_field('PATCH')); ?>

        <div class="input-group">
            <label>Enter Name</label>
            <input type="text" name="name" value= <?php echo e($employee->name); ?> >
        </div>
        <div class="input-group">
            <label>Enter age</label>
            <input type="number" name="age" value= <?php echo e($employee->age); ?> >
        </div>
        <div class="input-group">
            <label>Enter Phone Number</label>
            <input type="number" name="phonenumber" value= <?php echo e($employee->phonenumber); ?> >
        </div>
        <div class="input-group">
            <label>Enter Email-ID</label>
            <input type="text" name="email" value=  <?php echo e($employee->email); ?>>
        </div>
        <div class="input-group">
            <label>Enter Phone Number</label>
            <input type="number" name="phonenumber" value=  <?php echo e($employee->phonenumber); ?> >
        </div>
        <div class="input-group">
            <label>Enter ardhar number</label>
            <input type="number" name="aadharnumber" value=  <?php echo e($employee->aadharnumber); ?> >
        </div>
        
        <div class="input-group">
            <label>Enter Password</label>
            <input type="password" name="password" value=  <?php echo e($employee->npassword); ?>>
        </div>
        <div class="input-group">
            <button class="btn" name="submit">Change details</button>
        </div>
    </form>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/editemployee.blade.php ENDPATH**/ ?>