<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/home.css">
    <title>Home</title>
</head>
<body>
<div class="image-wrapper" id="homeup">
        <br>
        <h1>Success begins within here</h1>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <form class="form-inline" action="/action_page.php">
        <input type="text" placeholder="Book Name" name="bookname">
        <input type="text" placeholder="Author" name="Dauthor">
        <button type="submit">Submit</button>
        </form>
    </div>
    <div class="container-con" style="background-color:white;">
    <div class="image-wrapper1">
        <img src="./../images/librarymini.jpg" alt="">
        </div>
        <div class="content-display">
            <br><br>
            <h1 style="color:black;">Working here already?</h2>
            <br>
            <h4 style="color:rgb(5, 71, 82);">Let's get your day started at here. Login to your </h4>
            <br><br>
            <button class="btn-share">Login</button>
        </div>
    </div>
    <div class="container-con">
    <div class="image-wrapper1">
            <img src="./../images/librarymini3.jpeg" alt="">
        </div>
        <div class="content-display">
            <br><br>
            <h1 style="color:white;" >Looking for a part-time?</h2>
            <br>
            <h4 style="color:white;">Let's make this place much more than a library to you.<br>Flexiblw work hours lets make your school life easy.<br>Contact us today</h4>
        </div>
        
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\library\resources\views/home.blade.php ENDPATH**/ ?>