
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">
    <?php echo e($employee->name); ?>

  </div>
  <form action="">
      <?php echo csrf_field(); ?>;
      <?php echo e(method_field('DELETE')); ?>

  <div class="card-body">
    <p class="card-text">Employee-ID: <?php echo e($employee->id); ?> </p>
    <h5 class="card-title">Age: <?php echo e($employee->age); ?> </h5>
    <p class="card-text">Aadhar Number: <?php echo e($employee->aadharnumber); ?> </p>
    <p class="card-text">Email-ID: <?php echo e($employee->emailid); ?> </p>
    <p class="card-text">Phone Number: <?php echo e($employee->phonenumber); ?> </p>
    <a href="/admin/books/<?php echo e($employee->id); ?>/edit" class="btn btn-primary">Edit Details</a>
    <a href="/admin/books/<?php echo e($employee->id); ?>" class="btn btn-primary" value="DELETE">Delete</a>
  </div>
  </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/employeeid.blade.php ENDPATH**/ ?>