
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="/css/form.css"> 
    <style>
        
        
    </style>

</head>
<body>
    <div class="header">
        <h2>Login Here!</h2>
    </div>
      
    <form method="post" action="login.php" class="bookform">
  
        <div class="input-group">
            <label>Enter Email-ID</label>
            <input type="text" name="email" >
        </div>
        <div class="input-group">
            <label>Enter Password</label>
            <input type="password" name="password">
        </div>
        <div class="input-group">
            <button class="btn" name="submit">Login</button>
        </div>
    </form>
    </body>
 
 </html>
<?php /**PATH C:\xampp\htdocs\library\resources\views/login.blade.php ENDPATH**/ ?>