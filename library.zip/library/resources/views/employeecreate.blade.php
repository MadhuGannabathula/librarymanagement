
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="/css/form.css"> 
    <style>
        
        
    </style>

</head>
<body>
    <div class="header">
        <h2>Create Employee</h2>
    </div>
      
    <form method="post" action="/admin/employees" class="bookform">
    @csrf;
        <div class="input-group">
            <label>Enter Name</label>
            <input type="text" name="name" >
        </div>
        <div class="input-group">
            <label>Enter Email-ID</label>
            <input type="text" name="email" >
        </div>
        <div class="input-group">
            <label>Enter age</label>
            <input type="number" name="age" >
        </div>
        <div class="input-group">
            <label>Enter Phone Number</label>
            <input type="number" name="phonenumber" >
        </div>
        <div class="input-group">
            <label>Enter ardhar number</label>
            <input type="number" name="aadharnumber" >
        </div>
        
        <div class="input-group">
            <label>Enter Password</label>
            <input type="password" name="password">
        </div>
        <div class="input-group">
            <label>Re-enter Password</label>
            <input type="password" name="password2">
        </div>
        <div class="input-group">
            <button class="btn" name="submit">Login</button>
        </div>
    </form>
    </body>
 
 </html>
