<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/home.css">
    <link rel="stylesheet" href="/css/form.css"> 
    <title>Home</title>
    <style>
        .bookform, .content {
            width: 60%;
        }
        .header {
            width: 60%;
            margin: 10px auto 0px;
        }
    </style>
</head>
<body>
    <div class="image-wrapper" id="homeup">
        <br>
        <h1>Success begins within here</h1>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <form class="form-inline" action="/action_page.php">
        <input type="text" placeholder="Book Name" name="bookname">
        <input type="text" placeholder="Author" name="Dauthor">
        <button type="submit">Submit</button>
        </form>
    </div>
    <div class="container-con" style="background-color:white;">
        <div class="image-wrapper1">
        <div class="header">
        <h2>Take Home</h2>
        </div>
        <form method="post" action="login.php" class="bookform">
        <div class="input-group">
            <label>Enter Book-ID</label>
            <input type="text" name="bookid" >
        </div>
        <div class="input-group">
            <label>Enter Student-ID</label>
            <input type="text" name="studentid">
        </div>
        <div class="input-group">
            <button class="btn" name="submit">Login</button>
        </div>
        </form>
        </div>
        <div class="image-wrapper1">
        <div class="header">
        <h2>Return Book</h2>
        </div>
        <form method="post" action="login.php" class="bookform">
        <div class="input-group">
            <label>Enter Book-ID</label>
            <input type="text" name="bookid" >
        </div>
        <div class="input-group">
            <label>Enter Student-ID</label>
            <input type="text" name="studentid">
        </div>
        <div class="input-group">
            <button class="btn" name="submit">Login</button>
        </div>
        </form>
        </div>
    <br><br><br>      
    </div>
    <div class="container-con" style="background-color:white;">
        <div class="content-display">
            <br><br>
            <h1 style="color:black;">Completed your work for the day?</h2>
            <br>
            <h4 style="color:rgb(5, 71, 82);">Let's get you out of here. Click that button and you can be out </h4>
            <br><br>
            <button class="btn-share">Logout</button>
        </div>
        <div class="image-wrapper1">
            <img src="./../images/librarymini.jpg" alt="">
        </div>
    </div>
</body>
</html>